# drag_and_drop
This project is on drag and drop system.  It drags images from one container to another container with indication on success.
